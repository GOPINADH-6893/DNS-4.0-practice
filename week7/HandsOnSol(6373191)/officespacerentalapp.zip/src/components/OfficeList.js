// src/components/OfficeList.js
import React from "react";

function OfficeList() {
  const heading = "Office Space";
  const jsxAtt = (
    <img
      src={
        "https://t4.ftcdn.net/jpg/03/84/55/29/360_F_384552930_zPoe9zgmCF7qgt8fqSedcyJ6C6Ye3dFs.jpg"
      }
      width="25%"
      height="25%"
      alt="Office Space"
      style={{ borderRadius: "8px" }}
    />
  );

  const officeList = [
    { Name: "DBS", Rent: 50000, Address: "Chennai" },
    { Name: "WeWork", Rent: 85000, Address: "Bangalore" },
  ];

  return (
    <div>
      <h1>{heading}, at Affordable Range</h1>
      {jsxAtt}
      <hr />
      {officeList.map((item, index) => {
        const rentClass = item.Rent <= 60000 ? "textRed" : "textGreen";

        return (
          <div key={index} className="office-card">
            <h2>Name: {item.Name}</h2>
            <h3 className={rentClass}>Rent: ₹{item.Rent}</h3>
            <h4>Address: {item.Address}</h4>
          </div>
        );
      })}
    </div>
  );
}

export default OfficeList;
