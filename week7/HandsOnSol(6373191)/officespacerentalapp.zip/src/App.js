import React from "react";
import "./styles.css";
import OfficeList from "./components/OfficeList";

function App() {
  return (
    <div className="App">
      <OfficeList />
    </div>
  );
}

export default App;
