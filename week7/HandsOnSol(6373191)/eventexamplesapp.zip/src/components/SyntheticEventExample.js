import React from "react";

function SyntheticEventExample() {
  const handleClick = () => {
    alert("I was clicked");
  };

  return (
    <div>
      <button onClick={handleClick}>Click Me</button>
    </div>
  );
}

export default SyntheticEventExample;
