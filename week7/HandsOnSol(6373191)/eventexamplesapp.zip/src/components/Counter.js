import React, { useState } from "react";

function Counter() {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
    console.log("Hello!");
    console.log("You clicked the increment button.");
  };

  const decrement = () => {
    setCount(count - 1);
  };

  const sayWelcome = () => {
    alert("Welcome");
  };

  const handleClick = () => {
    alert("I was clicked");
  };

  return (
    <div>
      <h2>{count}</h2>
      <button onClick={increment}>Increment</button>
      <br />
      <br />
      <button onClick={decrement}>Decrement</button>
      <br />
      <br />
      <button onClick={sayWelcome}>Say welcome</button>
      <br />
      <br />
      <button onClick={handleClick}>Click on me</button>
    </div>
  );
}

export default Counter;
