import React, { useState } from "react";
import "../styles.css";

function CurrencyConverter() {
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    // Let's say 1 Euro = 80 Rupees
    const conversionRate = 80;
    const result = parseFloat(amount) * conversionRate;

    alert(`Converting to ${currency} Amount is ${result}`);
  };

  return (
    <div>
      <h2 className="green-heading">Currency Convertor!!!</h2>
      <form onSubmit={handleSubmit}>
        <label>Amount: </label>
        <input
          type="text"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <br />
        <br />
        <label>Currency: </label>
        <input
          type="text"
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
        />
        <br />
        <br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default CurrencyConverter;
