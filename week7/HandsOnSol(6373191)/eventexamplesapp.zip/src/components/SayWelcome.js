import React from "react";

function SayWelcome() {
  const showMessage = (message) => {
    alert(`Message: ${message}`);
  };

  return (
    <div>
      <button onClick={() => showMessage("Welcome")}>Say Welcome</button>
    </div>
  );
}

export default SayWelcome;
