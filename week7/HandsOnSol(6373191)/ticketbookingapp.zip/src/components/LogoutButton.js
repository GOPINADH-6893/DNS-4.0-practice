import React from "react";

function LogoutButton({ onClick }) {
  return <button onClick={onClick}>Logout</button>;
}

export default LogoutButton;
