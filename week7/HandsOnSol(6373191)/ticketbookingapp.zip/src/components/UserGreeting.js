import React from "react";

function UserGreeting() {
  return (
    <div>
      <h2>Flight Details</h2>
      <ul>
        <li>✈️ Flight: AI-203 | From: Delhi | To: London | Time: 10:00 AM</li>
        <li>✈️ Flight: EK-401 | From: Mumbai | To: Dubai | Time: 1:00 PM</li>
      </ul>
      <button>Book Ticket</button>
    </div>
  );
}

export default UserGreeting;
