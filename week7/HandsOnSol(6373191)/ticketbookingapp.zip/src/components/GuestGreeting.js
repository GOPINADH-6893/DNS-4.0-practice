import React from "react";

function GuestGreeting() {
  return (
    <div>
      <h2>You are browsing as a Guest 👤</h2>
      <h3>please sign Up</h3>
      <p>Login to view and book flight tickets.</p>
    </div>
  );
}

export default GuestGreeting;
