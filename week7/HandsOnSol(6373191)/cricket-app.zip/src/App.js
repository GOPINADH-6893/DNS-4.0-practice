import React from "react";
import ListOfPlayers from "./components/ListOfPlayers";
import ScoreBelow70 from "./components/ScoreBelow70";
import { OddPlayers, EvenPlayers } from "./components/IndianPlayers";
import ListOfIndianPlayers from "./components/ListOfIndianPlayers";

function App() {
  const flag = true;

  const players = [
    { name: "Virat", score: 95 },
    { name: "Rohit", score: 82 },
    { name: "Dhoni", score: 45 },
    { name: "Rahul", score: 62 },
    { name: "Shreyas", score: 88 },
    { name: "Raina", score: 55 },
    { name: "Jadeja", score: 76 },
    { name: "Ashwin", score: 68 },
    { name: "Bumrah", score: 90 },
    { name: "Shami", score: 61 },
    { name: "Sundar", score: 73 },
  ];

  const IndianTeam = ["Virat", "Rohit", "Dhoni", "Rahul", "Shreyas", "Raina"];

  const T20Players = ["First Player", "Second Player", "Third Player"];
  const RanjiTrophyPlayers = ["Fourth Player", "Fifth Player", "Sixth Player"];
  const IndianPlayers = [...T20Players, ...RanjiTrophyPlayers];

  if (flag === true) {
    return (
      <div>
        <h1>List of Players</h1>
        <ListOfPlayers players={players} />
        <hr />
        <h1>List of Players having Scores Less than 70</h1>
        <ScoreBelow70 players={players} />
      </div>
    );
  } else {
    return (
      <div>
        <h1>Indian Team</h1>
        <h2>Odd Players</h2>
        <OddPlayers players={IndianTeam} />
        <hr />
        <h2>Even Players</h2>
        <EvenPlayers players={IndianTeam} />
        <hr />
        <h2>List of Indian Players Merged</h2>
        <ListOfIndianPlayers players={IndianPlayers} />
      </div>
    );
  }
}

export default App;
