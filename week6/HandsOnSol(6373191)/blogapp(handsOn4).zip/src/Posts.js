// src/Posts.js
import React from "react";
import Post from "./post";

class Posts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: [],
    };
  }

  loadPosts = async () => {
    try {
      const res = await fetch("https://jsonplaceholder.typicode.com/posts");
      const data = await res.json();
      const postsList = data.map((p) => new Post(p.id, p.title, p.body));
      this.setState({ posts: postsList });
    } catch (err) {
      alert("Error loading posts: " + err.message);
    }
  };

  componentDidMount() {
    this.loadPosts();
  }

  componentDidCatch(error, info) {
    alert("Component error: " + error.toString());
  }

  render() {
    return (
      <div>
        <h2>Posts List</h2>
        {this.state.posts.map((post) => (
          <div key={post.id}>
            <h3>{post.title}</h3>
            <p>{post.body}</p>
            <hr />
          </div>
        ))}
      </div>
    );
  }
}

export default Posts;
