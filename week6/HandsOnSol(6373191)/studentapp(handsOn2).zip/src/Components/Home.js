import React, { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div>
        <h3>Welcome to Home Page of Student Management Portal</h3>
      </div>
    );
  }
}
